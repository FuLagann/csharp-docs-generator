
// Variables
const SearchHelper = (function() {
	// Variables
	/** @type {{
			[key : string] : {
				link : string;
				tags : string[];
				types : {
					[key : string] : {
						link : string;
						tags : string[];
						members : {
							link : string;
							tags : string[];
							name : string;
						}[];
					}
				}
			}
		}} - The js object used for searching.*/
	let searchJson = {
 "SchoolSys": {
  "link": "schoolsys.html",
  "tags": [
   "namespace"
  ],
  "types": {
   "BaseMember": {
    "link": "schoolsys.basemember.html",
    "tags": [
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.basemember.html#BaseMember",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "BaseMember()"
     },
     {
      "link": "schoolsys.basemember.html#Id",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Id"
     },
     {
      "link": "schoolsys.basemember.html#OnMessege",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMessege"
     },
     {
      "link": "schoolsys.basemember.html#OnMesseged",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMesseged"
     },
     {
      "link": "schoolsys.basemember.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.basemember.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.basemember.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.basemember.html#GetSchedule",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetSchedule()"
     },
     {
      "link": "schoolsys.basemember.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.basemember.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.basemember.html#SendMessage(T,K)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SendMessage&lt;T,K&gt;(T message, K data)"
     },
     {
      "link": "schoolsys.basemember.html#SignIn",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignIn()"
     },
     {
      "link": "schoolsys.basemember.html#SignOut",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignOut()"
     },
     {
      "link": "schoolsys.basemember.html#Talk(System.String)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Talk(string message)"
     },
     {
      "link": "schoolsys.basemember.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     }
    ]
   },
   "BaseMember.PublicBaseMember": {
    "link": "schoolsys.basemember.publicbasemember.html",
    "tags": [
     "nested",
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.basemember.publicbasemember.html#BaseMember.PublicBaseMember",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "BaseMember.PublicBaseMember()"
     },
     {
      "link": "schoolsys.basemember.publicbasemember.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.basemember.publicbasemember.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.basemember.publicbasemember.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.basemember.publicbasemember.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.basemember.publicbasemember.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.basemember.publicbasemember.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     }
    ]
   },
   "FacultyMember": {
    "link": "schoolsys.facultymember.html",
    "tags": [
     "sealed",
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.facultymember.html#FacultyMember(SchoolSys.StudentMember,System.String)",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "FacultyMember(StudentMember history, string id)"
     },
     {
      "link": "schoolsys.facultymember.html#id",
      "tags": [
       "member",
       "field"
      ],
      "name": "id"
     },
     {
      "link": "schoolsys.facultymember.html#studentHistory",
      "tags": [
       "member",
       "field"
      ],
      "name": "studentHistory"
     },
     {
      "link": "schoolsys.facultymember.html#Id",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Id"
     },
     {
      "link": "schoolsys.facultymember.html#OnMessege",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMessege"
     },
     {
      "link": "schoolsys.facultymember.html#OnMesseged",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMesseged"
     },
     {
      "link": "schoolsys.facultymember.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.facultymember.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.facultymember.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.facultymember.html#GetSchedule",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetSchedule()"
     },
     {
      "link": "schoolsys.facultymember.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.facultymember.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.facultymember.html#SendMessage(T,K)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SendMessage&lt;T,K&gt;(T message, K data)"
     },
     {
      "link": "schoolsys.facultymember.html#SignIn",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignIn()"
     },
     {
      "link": "schoolsys.facultymember.html#SignOut",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignOut()"
     },
     {
      "link": "schoolsys.facultymember.html#Talk(System.String)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Talk(string message)"
     },
     {
      "link": "schoolsys.facultymember.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     }
    ]
   },
   "IMember": {
    "link": "schoolsys.imember.html",
    "tags": [
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.imember.html#Id",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Id"
     },
     {
      "link": "schoolsys.imember.html#GetSchedule",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "GetSchedule()"
     },
     {
      "link": "schoolsys.imember.html#SignIn",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "SignIn()"
     },
     {
      "link": "schoolsys.imember.html#SignOut",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignOut()"
     }
    ]
   },
   "ISchedule": {
    "link": "schoolsys.ischedule.html",
    "tags": [
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.ischedule.html#Description",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Description"
     },
     {
      "link": "schoolsys.ischedule.html#IsComplete",
      "tags": [
       "member",
       "property",
       "virtual",
       "virtual"
      ],
      "name": "IsComplete"
     },
     {
      "link": "schoolsys.ischedule.html#Time",
      "tags": [
       "member",
       "property",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Time"
     }
    ]
   },
   "MemberList": {
    "link": "schoolsys.memberlist.html",
    "tags": [
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.memberlist.html#MemberList",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "MemberList()"
     },
     {
      "link": "schoolsys.memberlist.html#Capacity",
      "tags": [
       "member",
       "property"
      ],
      "name": "Capacity"
     },
     {
      "link": "schoolsys.memberlist.html#Count",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Count"
     },
     {
      "link": "schoolsys.memberlist.html#Item(System.Int32)",
      "tags": [
       "member",
       "property",
       "virtual",
       "virtual"
      ],
      "name": "Item(int index)"
     },
     {
      "link": "schoolsys.memberlist.html#Add(SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Add(IMember item)"
     },
     {
      "link": "schoolsys.memberlist.html#AddRange(System.Collections.Generic.IEnumerable-1)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "AddRange(IEnumerable&lt;IMember&gt; collection)"
     },
     {
      "link": "schoolsys.memberlist.html#AsReadOnly",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "AsReadOnly()"
     },
     {
      "link": "schoolsys.memberlist.html#BinarySearch(System.Int32,System.Int32,SchoolSys.IMember,System.Collections.Generic.IComparer-1)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "BinarySearch(int index, int count, IMember item, IComparer&lt;IMember&gt; comparer)"
     },
     {
      "link": "schoolsys.memberlist.html#BinarySearch(SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "BinarySearch(IMember item)"
     },
     {
      "link": "schoolsys.memberlist.html#BinarySearch(SchoolSys.IMember,System.Collections.Generic.IComparer-1)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "BinarySearch(IMember item, IComparer&lt;IMember&gt; comparer)"
     },
     {
      "link": "schoolsys.memberlist.html#Clear",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Clear()"
     },
     {
      "link": "schoolsys.memberlist.html#Contains(SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Contains(IMember item)"
     },
     {
      "link": "schoolsys.memberlist.html#ConvertAll(System.Converter-2)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ConvertAll&lt;TOutput&gt;(Converter&lt;IMember, TOutput&gt; converter)"
     },
     {
      "link": "schoolsys.memberlist.html#CopyTo(SchoolSys.IMember,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "CopyTo(IMember[] array, int arrayIndex)"
     },
     {
      "link": "schoolsys.memberlist.html#CopyTo(SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "CopyTo(IMember[] array)"
     },
     {
      "link": "schoolsys.memberlist.html#CopyTo(System.Int32,SchoolSys.IMember,System.Int32,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "CopyTo(int index, IMember[] array, int arrayIndex, int count)"
     },
     {
      "link": "schoolsys.memberlist.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.memberlist.html#Exists(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Exists(Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.memberlist.html#Find(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Find(Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindAll(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindAll(Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindIndex(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindIndex(Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindIndex(System.Int32,System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindIndex(int startIndex, Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindIndex(System.Int32,System.Int32,System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindIndex(int startIndex, int count, Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindLast(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindLast(Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindLastIndex(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindLastIndex(Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindLastIndex(System.Int32,System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindLastIndex(int startIndex, Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#FindLastIndex(System.Int32,System.Int32,System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "FindLastIndex(int startIndex, int count, Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#ForEach(System.Action-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ForEach(Action&lt;IMember&gt; action)"
     },
     {
      "link": "schoolsys.memberlist.html#GetEnumerator",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetEnumerator()"
     },
     {
      "link": "schoolsys.memberlist.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.memberlist.html#GetRange(System.Int32,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetRange(int index, int count)"
     },
     {
      "link": "schoolsys.memberlist.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.memberlist.html#IndexOf(SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "IndexOf(IMember item)"
     },
     {
      "link": "schoolsys.memberlist.html#IndexOf(SchoolSys.IMember,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "IndexOf(IMember item, int index)"
     },
     {
      "link": "schoolsys.memberlist.html#IndexOf(SchoolSys.IMember,System.Int32,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "IndexOf(IMember item, int index, int count)"
     },
     {
      "link": "schoolsys.memberlist.html#Insert(System.Int32,SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Insert(int index, IMember item)"
     },
     {
      "link": "schoolsys.memberlist.html#InsertRange(System.Int32,System.Collections.Generic.IEnumerable-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "InsertRange(int index, IEnumerable&lt;IMember&gt; collection)"
     },
     {
      "link": "schoolsys.memberlist.html#LastIndexOf(SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "LastIndexOf(IMember item)"
     },
     {
      "link": "schoolsys.memberlist.html#LastIndexOf(SchoolSys.IMember,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "LastIndexOf(IMember item, int index)"
     },
     {
      "link": "schoolsys.memberlist.html#LastIndexOf(SchoolSys.IMember,System.Int32,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "LastIndexOf(IMember item, int index, int count)"
     },
     {
      "link": "schoolsys.memberlist.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.memberlist.html#Remove(SchoolSys.IMember)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Remove(IMember item)"
     },
     {
      "link": "schoolsys.memberlist.html#RemoveAll(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "RemoveAll(Predicate&lt;IMember&gt; match)"
     },
     {
      "link": "schoolsys.memberlist.html#RemoveAt(System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "RemoveAt(int index)"
     },
     {
      "link": "schoolsys.memberlist.html#RemoveRange(System.Int32,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "RemoveRange(int index, int count)"
     },
     {
      "link": "schoolsys.memberlist.html#Reverse",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Reverse()"
     },
     {
      "link": "schoolsys.memberlist.html#Reverse(System.Int32,System.Int32)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Reverse(int index, int count)"
     },
     {
      "link": "schoolsys.memberlist.html#SendMessage(T,K)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SendMessage&lt;T,K&gt;(T message, K data)"
     },
     {
      "link": "schoolsys.memberlist.html#Sort(System.Comparison-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Sort(Comparison&lt;IMember&gt; comparison)"
     },
     {
      "link": "schoolsys.memberlist.html#Sort(System.Int32,System.Int32,System.Collections.Generic.IComparer-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Sort(int index, int count, IComparer&lt;IMember&gt; comparer)"
     },
     {
      "link": "schoolsys.memberlist.html#Sort",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Sort()"
     },
     {
      "link": "schoolsys.memberlist.html#Sort(System.Collections.Generic.IComparer-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Sort(IComparer&lt;IMember&gt; comparer)"
     },
     {
      "link": "schoolsys.memberlist.html#ToArray",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToArray()"
     },
     {
      "link": "schoolsys.memberlist.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     },
     {
      "link": "schoolsys.memberlist.html#TrimExcess",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "TrimExcess()"
     },
     {
      "link": "schoolsys.memberlist.html#TrueForAll(System.Predicate-1)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "TrueForAll(Predicate&lt;IMember&gt; match)"
     }
    ]
   },
   "NamespaceDoc": {
    "link": "schoolsys.namespacedoc.html",
    "tags": [
     "static",
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.namespacedoc.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.namespacedoc.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.namespacedoc.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.namespacedoc.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.namespacedoc.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.namespacedoc.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     }
    ]
   },
   "StaffMember": {
    "link": "schoolsys.staffmember.html",
    "tags": [
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.staffmember.html#StaffMember(SchoolSys.StudentMember,System.String)",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "StaffMember(StudentMember history, string id)"
     },
     {
      "link": "schoolsys.staffmember.html#id",
      "tags": [
       "member",
       "field"
      ],
      "name": "id"
     },
     {
      "link": "schoolsys.staffmember.html#studentHistory",
      "tags": [
       "member",
       "field"
      ],
      "name": "studentHistory"
     },
     {
      "link": "schoolsys.staffmember.html#Id",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Id"
     },
     {
      "link": "schoolsys.staffmember.html#OnMessege",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMessege"
     },
     {
      "link": "schoolsys.staffmember.html#OnMesseged",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMesseged"
     },
     {
      "link": "schoolsys.staffmember.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.staffmember.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.staffmember.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.staffmember.html#GetSchedule",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetSchedule()"
     },
     {
      "link": "schoolsys.staffmember.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.staffmember.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.staffmember.html#SendMessage(T,K)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SendMessage&lt;T,K&gt;(T message, K data)"
     },
     {
      "link": "schoolsys.staffmember.html#SignIn",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignIn()"
     },
     {
      "link": "schoolsys.staffmember.html#SignOut",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignOut()"
     },
     {
      "link": "schoolsys.staffmember.html#Talk(System.String)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Talk(string message)"
     },
     {
      "link": "schoolsys.staffmember.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     }
    ]
   },
   "StudentMember": {
    "link": "schoolsys.studentmember.html",
    "tags": [
     "sealed",
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.studentmember.html#StudentMember(System.String)",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "StudentMember(string id)"
     },
     {
      "link": "schoolsys.studentmember.html#Id",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Id"
     },
     {
      "link": "schoolsys.studentmember.html#OnMessege",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMessege"
     },
     {
      "link": "schoolsys.studentmember.html#OnMesseged",
      "tags": [
       "member",
       "event"
      ],
      "name": "OnMesseged"
     },
     {
      "link": "schoolsys.studentmember.html#Clone",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Clone()"
     },
     {
      "link": "schoolsys.studentmember.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.studentmember.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.studentmember.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.studentmember.html#GetSchedule",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetSchedule()"
     },
     {
      "link": "schoolsys.studentmember.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.studentmember.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.studentmember.html#SendMessage(T,K)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SendMessage&lt;T,K&gt;(T message, K data)"
     },
     {
      "link": "schoolsys.studentmember.html#SignIn",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignIn()"
     },
     {
      "link": "schoolsys.studentmember.html#SignOut",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignOut()"
     },
     {
      "link": "schoolsys.studentmember.html#Talk(System.String)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Talk(string message)"
     },
     {
      "link": "schoolsys.studentmember.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     },
     {
      "link": "schoolsys.studentmember.html#GenerateId(System.Int32)",
      "tags": [
       "member",
       "static",
       "method"
      ],
      "name": "GenerateId(int seed = 10203040)"
     },
     {
      "link": "schoolsys.studentmember.html#op_Implicit__StaffMember(SchoolSys.StudentMember)",
      "tags": [
       "member",
       "static",
       "operator"
      ],
      "name": "op_Implicit__StaffMember(StudentMember obj)"
     }
    ]
   },
   "TimeBlock": {
    "link": "schoolsys.timeblock.html",
    "tags": [
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.timeblock.html#Day",
      "tags": [
       "member",
       "static",
       "field"
      ],
      "name": "Day"
     },
     {
      "link": "schoolsys.timeblock.html#Evening",
      "tags": [
       "member",
       "static",
       "field"
      ],
      "name": "Evening"
     },
     {
      "link": "schoolsys.timeblock.html#Morning",
      "tags": [
       "member",
       "static",
       "field"
      ],
      "name": "Morning"
     },
     {
      "link": "schoolsys.timeblock.html#Online",
      "tags": [
       "member",
       "static",
       "field"
      ],
      "name": "Online"
     },
     {
      "link": "schoolsys.timeblock.html#CompareTo(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "CompareTo(object target)"
     },
     {
      "link": "schoolsys.timeblock.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.timeblock.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.timeblock.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.timeblock.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.timeblock.html#GetTypeCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetTypeCode()"
     },
     {
      "link": "schoolsys.timeblock.html#HasFlag(System.Enum)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "HasFlag(enum flag)"
     },
     {
      "link": "schoolsys.timeblock.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.timeblock.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     },
     {
      "link": "schoolsys.timeblock.html#ToString(System.String,System.IFormatProvider)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString(string format, IFormatProvider provider)"
     },
     {
      "link": "schoolsys.timeblock.html#ToString(System.String)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString(string format)"
     },
     {
      "link": "schoolsys.timeblock.html#ToString(System.IFormatProvider)",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString(IFormatProvider provider)"
     }
    ]
   }
  }
 },
 "SchoolSys.Guests": {
  "link": "schoolsys.guests.html",
  "tags": [
   "namespace"
  ],
  "types": {
   "GuestMember&lt;T&gt;": {
    "link": "schoolsys.guests.guestmember-1.html",
    "tags": [
     "sealed",
     "type"
    ],
    "members": [
     {
      "link": "schoolsys.guests.guestmember-1.html#GuestMember(T)",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "GuestMember(T member)"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#Id",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Id"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#Member",
      "tags": [
       "member",
       "property",
       "virtual"
      ],
      "name": "Member"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#GetSchedule",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetSchedule()"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#SignIn",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignIn()"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#SignOut",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "SignOut()"
     },
     {
      "link": "schoolsys.guests.guestmember-1.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     }
    ]
   }
  }
 },
 "Test": {
  "link": "test.html",
  "tags": [
   "namespace"
  ],
  "types": {
   "Temp": {
    "link": "test.temp.html",
    "tags": [
     "type"
    ],
    "members": [
     {
      "link": "test.temp.html#Temp",
      "tags": [
       "member",
       "constructor"
      ],
      "name": "Temp()"
     },
     {
      "link": "test.temp.html#Equals(System.Object)",
      "tags": [
       "member",
       "method",
       "virtual"
      ],
      "name": "Equals(object obj)"
     },
     {
      "link": "test.temp.html#Finalize",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual"
      ],
      "name": "Finalize()"
     },
     {
      "link": "test.temp.html#GetHashCode",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetHashCode()"
     },
     {
      "link": "test.temp.html#GetType",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "GetType()"
     },
     {
      "link": "test.temp.html#MemberwiseClone",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "MemberwiseClone()"
     },
     {
      "link": "test.temp.html#ToString",
      "tags": [
       "member",
       "method",
       "virtual",
       "virtual",
       "virtual",
       "virtual"
      ],
      "name": "ToString()"
     }
    ]
   }
  }
 }
};
	/**@type {string[]} - The value to search for.*/
	let vals;
	/**@type {{
			only : string[],
			strictOnly : string[],
			exclude : string[],
			regex : string,
			acceptAll : boolean
		}} - The filter to exclude objects from the search.*/
	let filter;
	/**@type {string} - The id of the search bar.*/
	let searchBarId = "search-bar";
	/**@type {string} - The id of the search results window.*/
	let searchResultsId = "search-results";
	/**@type {string} - The id of the search help menu in the modal.*/
	let searchBarHelpId = "search-help-desc";
	/**@type {HTMLElement} - The list element that will be outputting the found results.*/
	let outputList;
	/**@type {HTMLElement} - The window element that will be toggled on and off whenever searching begins.*/
	let outputWindow;
	/**@type {number} - The id of the timeout function.*/
	let timeout;
	/**@type {number} - The index to the namespace to look into.*/
	let namespaceIndex;
	/**@type {number} - The index to the type to look into.*/
	let typeIndex;
	/**@type {number} - The index to the member to look into.*/
	let memberIndex;
	/**@type {string[]} - The list of namespaces used for searching.*/
	let namespaceList;
	/**@type {string[]} - The list of type used for searching.*/
	let typeList;
	/**@type {string} - The current namespace to search for first.*/
	let currNamespace;
	/**@type {string} - The current type to search for first.*/
	let currType;
	/**@type {string} - The name of the class that will pop the output window into focus.*/
	let outputWindowFocusClass = "active";
	/**@type {number} - The search interval.*/
	let searchInterval = 150;
	/**@type {number} - The starting search interval to make the user wait before the search starts.*/
	let startingSearchInterval = 250;
	/**@type {string} - The item that tells the user that it's searching.*/
	let searchingItem = '<li id="--searching-display-in-window--" style="text-align: center;">Searching...</li>';
	/**Sets the search interval. Make this number to small and you run the risk of freezing up the web app,
	 * this is to make the search pseudo-asynchronous.
	 * @param value {number} - The interval to wait between each iteration of the search.*/
	let setSearchInterval = function(value) { searchInterval = value; }
	/**Sets the starting search interval. Make this number to small and you run the risk of freezing up the web app,
	 * this is to make the search pseudo-asynchronous. This also stops the search bar from looking "glitchy".
	 * @param value {number} - The interval to wait before beginning the search.*/
	let setStartingSearchInterval = function(value) { startingSearchInterval = value; }
	/**Sets the output window's focus class to a specific class.
	 * @param value {string} - The new class that will make the output window appear.*/
	let setOutputWindowFocusClass = function(value) { outputWindowFocusClass = value; };
	/**Sets the current namespace and type to search for first.
	 * @param namespace {string} - The namespace to search for.
	 * @param type {string} - The type to search for.*/
	const setCurrent = function(namespace, type) {
		currNamespace = namespace;
		currType = type.replace(/</g, "&lt;").replace(/>/g, "&gt;");
	};
	/**Marks the result with a bolded mark of what the query string was.
	 * @param input {string} - The input string to mark.
	 * @param value {string} - The value string to mark win.
	 * @return {string} Returns the input string marked by the query string.*/
	const markResult = function(input, value) {
		// Variables
		let start = input.toLowerCase().indexOf(value);
		let end = start + value.length;
		
		return (
			input.substring(0, start) +
			"<b>" + input.substring(start, end) + "</b>" +
			input.substring(end)
		);
	};
	/**Starts searching through the API for anything similar to the given value.
	 * @param value {string} - The value used to query the API.
	 * @param windowId {string} - The id of the window to toggle on and off when searching.
	 * @param listId {string} - The id of the list to output the search results.*/
	const startSearch = function(value, windowId, listId) {
		if(timeout) {
			window.clearTimeout(timeout);
		}
		outputWindow = document.getElementById(windowId);
		if(value == "") {
			outputWindow.classList.remove(outputWindowFocusClass);
			return;
		}
		getValuesAndFilter(value);
		outputList = document.getElementById(listId);
		outputList.innerHTML = searchingItem;
		outputWindow.classList.add(outputWindowFocusClass);
		namespaceIndex = (currNamespace && currType ? -1 : 0);
		typeIndex = 0;
		memberIndex = 0;
		timeout = setTimeout(search, startingSearchInterval);
	};
	/**Gets the value and filter content from the given input value.
	 * @param value {string} - The input value from the user.*/
	const getValuesAndFilter = function(value) {
		// Variables
		const temp = value.toLowerCase().trim().replace(/</g, "&lt;").replace(/>/g, "&gt;").split(' ');
		let index = -1;
		
		vals = [];
		filter = {};
		
		for(let i = 0; i < temp.length; i++) {
			index = temp[i].indexOf(':');
			
			if(index == -1) {
				vals.push(temp[i]);
			}
			else {
				switch(temp[i].substring(0, index)) {
					case "only": {
						if(!filter.only) {
							filter.only = [];
						}
						filter.only = filter.only.concat(
							temp[i].substring(index + 1).split(',')
						);
					} break;
					case "strict-only": {
						if(!filter.strictOnly) {
							filter.strictOnly = [];
						}
						filter.strictOnly = filter.strictOnly.concat(
							temp[i].substring(index + 1).split(',')
						);
					} break;
					case "exclude": {
						if(!filter.exclude) {
							filter.exclude = [];
						}
						filter.exclude = filter.exclude.concat(
							temp[i].substring(index + 1).split(',')
						);
					} break;
					case "regex": {
						filter.regex = temp[i].substring(index + 1);
					} break;
					case "accept-all": {
						filter.acceptAll = (temp[i].substring(index + 1) != "false");
					} break;
				}
			}
		}
		
		if(vals.length == 0 && (!filter.regex || filter.regex == "") && filter.acceptAll != false) {
			filter.acceptAll = true;
		}
	};
	/**Removes the searching item telling the user they are searching.
	 * @return Returns true if the searching item was the only item and was promptly removed.*/
	const removeSearchingItem = function() {
		// Variables
		let searchingItem = document.getElementById("--searching-display-in-window--");
		
		if(searchingItem) {
			outputList.removeChild(searchingItem);
			return (outputList.innerHTML == "");
		}
		return false;
	};
	/**Finds if the current iteration of searching yields that it is the current type being viewed.
	 * Used to skip first search results of the current type.
	 * @returns Returns true if the current type is the one being viewed.*/
	const isCurrentType = function() {
		if(currNamespace && currType) {
			return (
				namespaceList[namespaceIndex] == currNamespace &&
				typeList[typeIndex] == currType
			);
		}
		return false;
	};
	/**Formats the outputted list item, customizable for end-user.
	 * @param values {string[]} - The values that the user has queried.
	 * @param regex {string} - The regular expression used to find a match.
	 * @param link {string} - The link to where the item will take the user.
	 * @param name {string} - The name of the namespace/type/member.
	 * @param markResult {markResult} - A function that marks the query string as bold onto the inputted string.*/
	let formatOutputListItem = function(values, regex, link, name, markResult) {
		// Variables
		let results = name;
		let regexStr = "";
		
		if(regex) {
			regexStr = regex;
		}
		if(values && values.length > 0) {
			regexStr = (
				(regexStr == "" ? "" : regexStr + "|") + 
				escapeRegex(values.join('|'))
			);
		}
		if(regexStr != "") {
			results = results.replace(
				new RegExp("(" + regexStr + ")", "gi"),
				"<b>$1</b>"
			);
		}
		
		return (
			'<li><a href="' + link + '">' +
			results +
			"</a></li>"
		);
	};
	/**Escapes the regex to safely use the characters: ., *, +, -, ?, ^, $, {, }, (, ), [, ], and \.
	 * @param regex {string} - The regex string to escape.
	 * @returns {string} Returns the escaped regex string.*/
	const escapeRegex = function(regex) { return regex.replace(/[.*+\-?$^{}()\[\]\\]/g, "\\$&"); }
	/**Sets a custom format output list item.
	 * @param func {formatOutputListItem} - The new formatting function to set.*/
	const setFormatOutputListItem = function(func) { formatOutputListItem = func; };
	/**Finds if the given value is fulfilling the criteria for accepting into the output list.
	 * @param tags {string} - The tags of membership the object is apart of.
	 * @param value {string} - The string to look into.
	 * @returns {boolean} Returns true if the given value fulfills the criteria for accepting into the output list.*/
	const isFulfillingCriteria = function(tags, value) {
		// Variables
		const lowerCaseValue = value.toLowerCase();
		
		if(filter.strictOnly) {
			for(let i = 0; i < filter.strictOnly.length; i++) {
				if(tags.indexOf(filter.strictOnly[i]) == -1) {
					return false;
				}
			}
		}
		if(filter.only) {
			// Variables
			let found = false;
			
			for(let i = 0; i < filter.only.length; i++) {
				if(tags.indexOf(filter.only[i]) != -1) {
					found = true;
					break;
				}
			}
			
			if(!found) { return false; }
		}
		if(filter.exclude) {
			// Variables
			let item;
			
			for(let i = 0; i < filter.exclude.length; i++) {
				item = filter.exclude[i]
				
				if(tags.indexOf(item) != -1) {
					return false;
				}
			}
		}
		
		if(filter.acceptAll == true) {
			return true;
		}
		
		if(filter.regex) {
			if(lowerCaseValue.match(new RegExp(filter.regex, "gi"))) {
				return true;
			}
		}
		
		for(let i = 0; i < vals.length; i++) {
			if(lowerCaseValue.match(new RegExp(escapeRegex(vals[i]), "gi"))) {
				return true;
			}
		}
		
		return false;
	};
	/**Searches through the entire API little by little.*/
	const search = function() {
		for(let i = 0; i < 100; i++) {
			if(!namespaceList && namespaceIndex == 0) {
				namespaceList = Object.keys(searchJson);
			}
			if(namespaceIndex >= 0 && typeIndex == 0) {
				typeList = Object.keys(searchJson[namespaceList[namespaceIndex]].types);
			}
		
			if(namespaceIndex == -1) {
				// Variables
				const namespace = searchJson[currNamespace];
				const type = namespace.types[currType];
				const member = type.members[memberIndex];
				let name;
				
				if(memberIndex == 0) {
					if(isFulfillingCriteria(namespace.tags, currNamespace)) {
						outputList.innerHTML += formatOutputListItem(
							vals,
							filter.regex,
							namespace.link,
							currNamespace,
							markResult
						);
					}
					name = currNamespace + "." + currType;
					if(isFulfillingCriteria(type.tags, name)) {
						outputList.innerHTML += formatOutputListItem(
							vals,
							filter.regex,
							type.link,
							name,
							markResult
						);
					}
				}
				
				name = currNamespace + "." + currType + "." + member.name;
				if(isFulfillingCriteria(member.tags, name)) {
					outputList.innerHTML += formatOutputListItem(
						vals,
						filter.regex,
						member.link,
						name,
						markResult
					);
				}
				
				memberIndex++;
				if(memberIndex >= type.members.length) {
					memberIndex = 0;
					namespaceIndex++;
				}
			}
			else {
				// Variables
				const namespace = searchJson[namespaceList[namespaceIndex]];
				const type = namespace.types[typeList[typeIndex]];
				const member = type.members[memberIndex];
				let name;
				
				if(typeIndex == 0 && memberIndex == 0) {
					if(!currNamespace || namespaceList[namespaceIndex] != currNamespace) {
						if(!isCurrentType() && namespace) {
							name = namespaceList[namespaceIndex];
							if(isFulfillingCriteria(namespace.tags, name)) {
								outputList.innerHTML += formatOutputListItem(
									vals,
									filter.regex,
									namespace.link,
									name,
									markResult
								);
							}
						}
					}
				}
				if(memberIndex == 0) {
					if(!isCurrentType()) {
						name = namespaceList[namespaceIndex] + "." + typeList[typeIndex];
						if(isFulfillingCriteria(type.tags, name)) {
							outputList.innerHTML += formatOutputListItem(
								vals,
								filter.regex,
								type.link,
								name,
								markResult
							);
						}
					}
				}
				
				if(!isCurrentType() && member) {
					name = namespaceList[namespaceIndex] + "." + typeList[typeIndex] + "." + member.name;
					if(isFulfillingCriteria(member.tags, name)) {
						outputList.innerHTML += formatOutputListItem(
							vals,
							filter.regex,
							member.link,
							name,
							markResult
						);
					}
				}
				
				memberIndex++;
				if(type) {
					if(memberIndex >= type.members.length) {
						memberIndex = 0;
						
						typeIndex++;
					}
				}
				else {
					memberIndex = 0;
					typeIndex++;
				}
				if(typeIndex >= typeList.length) {
					typeIndex = 0;
					namespaceIndex++;
				}
			}
			
			if(namespaceList && namespaceIndex >= namespaceList.length) {
				break;
			}
		}
		
		if(namespaceIndex == -1 || namespaceIndex < namespaceList.length) {
			timeout = setTimeout(search, searchInterval);
		}
		else {
			if(removeSearchingItem()) {
				outputList.innerHTML = '<li style="text-align: center;">No results found!</li>';
			}
		}
	};
	/**Sets the search ids for search bar and search results window.
	 * @param searchBarID {string} - The id of the search bar to set.
	 * @param searchResultsID {string} - The id of the search results to set.*/
	const setSearchIds = function(searchBarID, searchResultsID, searchBarHelpID) {
		searchBarId = searchBarID;
		searchResultsId = searchResultsID;
		searchBarHelpId = searchBarHelpID;
	};
	/**Gets the help text of the search bar.
	 * @returns {string} Returns the help text for the search bar.*/
	const getHelpText = function(escapeHtml = false) {
		// Variables
		let help = "You can filter the search by using the following qualifiers:";
		
		if(escapeHtml) { help += "<br/><br/>\n"; }
		else { help += "\n\n"; }
		
		if(escapeHtml) { help += '<kbd class="search-bar-help-name">strict-only</kbd>'; }
		else { help += "  strict-only"; }
		help += " - Use an array of namespace, type, member, constructor, field,\n";
		help += "    event, property, method, static, sealed, virtual, nested, or operator to filter out types of objects,\n";
		help += "    seperated by a comma ( , ). Each category must be met to be accepted as a\n";
		help += "    result.";
		if(escapeHtml) { help += "<br/>\n&emsp;"; }
		else { help += "\n      "; }
		help += "Example: ";
		if(escapeHtml) { help += '<kbd class="search-bar-help-desc">strict-only:static,method</kbd>'; }
		else { help += "strict-only:static,method" }
		
		if(escapeHtml) { help += "<br/><br/>\n"; }
		else { help += "\n\n"; }
		
		if(escapeHtml) { help += '<kbd class="search-bar-help-name">only</kbd>'; }
		else { help += "  only"; }
		help += " - Use an array of namespace, type, member, constructor, field,\n";
		help += "    event, property, method, static, sealed, virtual, nested, or operator to filter out types of objects,\n";
		help += "    seperated by a comma ( , ).";
		if(escapeHtml) { help += "<br/>\n&emsp;"; }
		else { help += "\n      "; }
		help += "Example: ";
		if(escapeHtml) { help += '<kbd class="search-bar-help-desc">only:type,namespace</kbd>'; }
		else { help += "only:type,namespace"; }
		
		if(escapeHtml) { help += "<br/><br/>\n"; }
		else { help += "\n\n"; }
		
		if(escapeHtml) { help += '<kbd class="search-bar-help-name">exclude</kbd>'; }
		else { help += "  exclude"; }
		help += " - Use namespace, type, and member to exclude those objects from search,\n";
		help += "    seperated by a comma ( , ).";
		if(escapeHtml) { help += "<br/>\n&emsp;"; }
		else { help += "\n      "; }
		help += "Example: ";
		if(escapeHtml) { help += '<kbd class="search-bar-help-desc">exclude:namespace,type</kbd>'; }
		else { help += "exclude:namespace,type" }
		
		if(escapeHtml) { help += "<br/><br/>\n"; }
		else { help += "\n\n"; }
		
		if(escapeHtml) { help += '<kbd class="search-bar-help-name">regex</kbd>'; }
		else { help += "  regex"; }
		help += " - Use this to search by using a regular expression string.";
		if(escapeHtml) { help += "<br/>\n&emsp;"; }
		else { help += "\n      "; }
		help += "Example: ";
		if(escapeHtml) { help += '<kbd class="search-bar-help-desc">regex:mat\\d+</kbd>'; }
		else { help += "regex:mat\\d+"; }
		
		if(escapeHtml) { help += "<br/><br/>\n"; }
		else { help += "\n\n"; }
		
		if(escapeHtml) { help += '<kbd class="search-bar-help-name">accept-all</kbd>'; }
		else { help += "  accept-all"; }
		help += " - Set this to true to search for every object.";
		if(escapeHtml) { help += "<br/>\n&emsp;"; }
		else { help += "\n      "; }
		help += "Example: ";
		if(escapeHtml) { help += '<kbd class="search-bar-help-desc">accept-all:true</kbd>'; }
		else { help += "accept-all:true"; }
		
		return help;
	};
	
	window.addEventListener("load", function() {
		// Variables
		let searchBar = document.getElementById(searchBarId);
		let searchHelp = document.getElementById(searchBarHelpId);
		
		if(!searchBar) { return; }
		
		searchBar.title = getHelpText();
		searchHelp.innerHTML = getHelpText(true);
	});
	
	window.addEventListener("click", function(args) {
		// Variables
		let target = args.target;
		let results = document.getElementById(searchResultsId);
		
		if(!results) { return; }
		
		if(target.tagName == "A" && target.href != "") {
			results.classList.remove(outputWindowFocusClass);
			return;
		}
		
		if(target.id == searchBarId && target.value != "") {
			results.classList.add(outputWindowFocusClass);
			return;
		}
		if(!results.classList.contains(outputWindowFocusClass)) {
			return;
		}
		
		while(target != null) {
			if(target.id == searchBarId || target.id == searchResultsId) {
				break;
			}
			target = target.parentElement;
		}
		
		if(target == null) {
			results.classList.remove(outputWindowFocusClass);
		}
	});
	
	return {
		setCurrent: setCurrent,
		search: startSearch,
		setFormatOutputListItem: setFormatOutputListItem,
		setOutputWindowFocusClass: setOutputWindowFocusClass,
		setSearchInterval: setSearchInterval,
		setStartingSearchInterval: setStartingSearchInterval,
		setSearchIds: setSearchIds,
		getHelpText: getHelpText
	};
})();
